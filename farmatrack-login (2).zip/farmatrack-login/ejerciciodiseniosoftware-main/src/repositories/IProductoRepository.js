/**
 * src/repositories/IProductoRepository.js
 * Interfaz (contrato) del repositorio - patrón Repository.
 * Principio: Dependency Inversion - las capas superiores dependen de abstracciones.
 * Principio: Open/Closed - nuevas implementaciones no modifican el contrato.
 */

'use strict';

class IProductoRepository {
  async findAll() { throw new Error('Not implemented'); }
  async findById(id) { throw new Error('Not implemented'); }
  async findByCategoria(categoria) { throw new Error('Not implemented'); }
  async create(data) { throw new Error('Not implemented'); }
  async update(id, data) { throw new Error('Not implemented'); }
  async delete(id) { throw new Error('Not implemented'); }
  async count() { throw new Error('Not implemented'); }
}

module.exports = IProductoRepository;
