/**
 * src/utils/AppError.js
 * Clase de error personalizada para la aplicación.
 * Principio: Single Responsibility - encapsula el error de dominio.
 */

'use strict';

class AppError extends Error {
  constructor(message, statusCode = 500) {
    super(message);
    this.name = 'AppError';
    this.statusCode = statusCode;
    this.isOperational = true; // Distingue errores controlados de bugs
    Error.captureStackTrace(this, this.constructor);
  }
}

module.exports = AppError;
