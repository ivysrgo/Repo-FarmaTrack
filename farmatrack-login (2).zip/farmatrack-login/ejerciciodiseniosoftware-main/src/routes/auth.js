'use strict';
const express           = require('express');
const router            = express.Router();
const UsuarioRepository = require('../repositories/UsuarioRepository');
const AuthService       = require('../services/AuthService');
const AuthController    = require('../controllers/AuthController');

const usuarioRepo = new UsuarioRepository();
const authSvc     = new AuthService(usuarioRepo);
const authCtrl    = new AuthController(authSvc);

router.get('/login',    authCtrl.showLogin);
router.post('/login',   authCtrl.login);
router.post('/signup',  authCtrl.signup);
router.post('/logout',  authCtrl.logout);

// Recuperar contraseña (flujo demo — solo renderiza las vistas)
router.get('/recuperar', (req, res) => {
  res.render('auth/recuperar', {
    layout: 'layouts/auth', title: 'Recuperar contraseña',
    error: req.flash('error'), ok: req.flash('ok'), emailVal: '',
  });
});
router.post('/recuperar', (req, res) => {
  const { email } = req.body;
  if (!email || !email.trim()) {
    req.flash('error', 'Ingresa tu correo institucional.');
    return res.redirect('/auth/recuperar');
  }
  req.flash('ok', `Si el correo ${email} está registrado, recibirás las instrucciones en breve.`);
  res.redirect('/auth/recuperar');
});

// Reset contraseña (demo)
router.get('/reset', (req, res) => {
  res.render('auth/reset', {
    layout: 'layouts/auth', title: 'Nueva contraseña',
    error: req.flash('error'), token: req.query.token || 'demo-token',
  });
});
router.post('/reset', (req, res) => {
  const { password, confirmPassword } = req.body;
  if (!password || password !== confirmPassword) {
    req.flash('error', 'Las contraseñas no coinciden.');
    return res.redirect('/auth/reset');
  }
  res.redirect('/auth/login');
});

module.exports = router;
