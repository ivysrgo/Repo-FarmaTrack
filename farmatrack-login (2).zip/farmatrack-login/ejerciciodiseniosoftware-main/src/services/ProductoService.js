/**
 * src/services/ProductoService.js
 * Capa de lógica de negocio.
 * Principio: Single Responsibility - solo contiene reglas de negocio.
 * Principio: Dependency Inversion - depende de la abstracción IProductoRepository.
 * Patrón: Service Layer - centraliza la lógica de aplicación.
 */

'use strict';

const AppError = require('../utils/AppError');

class ProductoService {
  /**
   * @param {IProductoRepository} productoRepository - Inyección de dependencia
   */
  constructor(productoRepository) {
    this._repo = productoRepository;
  }

  /**
   * Obtiene todos los productos con estadísticas
   * @returns {Promise<{productos: Producto[], stats: Object}>}
   */
  async obtenerTodos() {
    const productos = await this._repo.findAll();
    const total = await this._repo.count();
    const categorias = await this._repo.getCategorias();

    const valorTotal = productos.reduce((sum, p) => sum + p.precio * p.cantidad, 0);

    return {
      productos,
      stats: {
        total,
        categorias: categorias.length,
        valorTotal: valorTotal.toFixed(2),
      },
    };
  }

  /**
   * Obtiene un producto por ID
   * @param {string} id
   * @returns {Promise<Producto>}
   */
  async obtenerPorId(id) {
    if (!id) throw new AppError('El ID es requerido', 400);

    const producto = await this._repo.findById(id);
    if (!producto) throw new AppError(`Producto con ID "${id}" no encontrado`, 404);

    return producto;
  }

  /**
   * Obtiene las categorías disponibles
   * @returns {Promise<string[]>}
   */
  async obtenerCategorias() {
    return this._repo.getCategorias();
  }

  /**
   * Crea un nuevo producto aplicando reglas de negocio
   * @param {Object} datos
   * @returns {Promise<Producto>}
   */
  async crear(datos) {
    this._validarDatos(datos);

    // Regla de negocio: precio mínimo
    if (datos.precio < 0) {
      throw new AppError('El precio no puede ser negativo', 400);
    }

    // Regla de negocio: cantidad mínima
    if (datos.cantidad < 0) {
      throw new AppError('La cantidad no puede ser negativa', 400);
    }

    return this._repo.create(datos);
  }

  /**
   * Actualiza un producto existente
   * @param {string} id
   * @param {Object} datos
   * @returns {Promise<Producto>}
   */
  async actualizar(id, datos) {
    // Verificar que existe antes de actualizar
    await this.obtenerPorId(id);

    if (datos.precio !== undefined && datos.precio < 0) {
      throw new AppError('El precio no puede ser negativo', 400);
    }

    if (datos.cantidad !== undefined && datos.cantidad < 0) {
      throw new AppError('La cantidad no puede ser negativa', 400);
    }

    const actualizado = await this._repo.update(id, datos);
    if (!actualizado) throw new AppError('Error al actualizar el producto', 500);

    return actualizado;
  }

  /**
   * Elimina un producto
   * @param {string} id
   * @returns {Promise<void>}
   */
  async eliminar(id) {
    await this.obtenerPorId(id); // Lanza 404 si no existe
    const eliminado = await this._repo.delete(id);
    if (!eliminado) throw new AppError('Error al eliminar el producto', 500);
  }

  /**
   * Validación básica de datos requeridos
   * @private
   */
  _validarDatos({ nombre, precio, cantidad }) {
    if (!nombre || nombre.trim() === '') {
      throw new AppError('El nombre del producto es requerido', 400);
    }
    if (precio === undefined || precio === null || precio === '') {
      throw new AppError('El precio es requerido', 400);
    }
    if (cantidad === undefined || cantidad === null || cantidad === '') {
      throw new AppError('La cantidad es requerida', 400);
    }
  }
}

module.exports = ProductoService;
