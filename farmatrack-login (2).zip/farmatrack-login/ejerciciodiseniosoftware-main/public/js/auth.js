/**
 * public/js/auth.js — FarmaTrack auth interactions
 */

/* ── Tabs Login / Signup ──────────────────────────────────── */
function switchTab(tab) {
  const isLogin  = tab === 'login';
  const tabLogin  = document.getElementById('tab-login');
  const tabSignup = document.getElementById('tab-signup');
  const panLogin  = document.getElementById('panel-login');
  const panSignup = document.getElementById('panel-signup');

  if (!tabLogin || !panLogin) return;

  tabLogin.classList.toggle('active',  isLogin);
  tabSignup.classList.toggle('active', !isLogin);
  panLogin.style.display  = isLogin  ? 'block' : 'none';
  panSignup.style.display = !isLogin ? 'block' : 'none';
}

/* ── Rellenar form de login con usuario demo ─────────────── */
function fillLogin(email, password) {
  const eInput = document.getElementById('email');
  const pInput = document.getElementById('password');
  if (!eInput || !pInput) return;

  eInput.value = email;
  pInput.value = password;

  // Efecto visual breve: borde active (mint-400)
  [eInput, pInput].forEach(el => {
    el.style.transition = 'border-color .2s';
    el.style.borderColor = '#5DCAA5';
    el.style.background  = '#fff';
    setTimeout(() => { el.style.borderColor = ''; el.style.background = ''; }, 800);
  });
}

/* ── Toggle mostrar/ocultar contraseña ───────────────────── */
function setupToggle(btnId, inputId) {
  const btn   = document.getElementById(btnId);
  const input = document.getElementById(inputId);
  if (!btn || !input) return;

  btn.addEventListener('click', () => {
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    btn.innerHTML = show
      ? `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`
      : `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`;
  });
}

/* ── Indicador de fortaleza de contraseña ────────────────── */
function checkStrength(val) {
  const wrap  = document.getElementById('pwdStrength');
  const label = document.getElementById('pwdLabel');
  const b1 = document.getElementById('bar1');
  const b2 = document.getElementById('bar2');
  const b3 = document.getElementById('bar3');
  if (!wrap) return;

  if (!val) { wrap.style.display = 'none'; return; }
  wrap.style.display = 'flex';

  let score = 0;
  if (val.length >= 4)  score++;
  if (val.length >= 8)  score++;
  if (/[A-Z]/.test(val) || /[0-9]/.test(val)) score++;

  const classes = ['', 'weak', 'medium', 'strong'];
  [b1, b2, b3].forEach((b, i) => {
    b.className = 'pwd-strength__bar ' + (i < score ? classes[score] : '');
  });

  const labels = ['', 'Débil', 'Media', 'Fuerte'];
  if (label) label.textContent = labels[score] || '';
}

/* ── Validación contraseñas coinciden ────────────────────── */
function checkMatch() {
  const p1  = document.getElementById('su-password');
  const p2  = document.getElementById('su-confirm');
  const err = document.getElementById('pwdMatchError');
  if (!p1 || !p2 || !err) return true;
  const match = p1.value === p2.value;
  err.style.display  = (!match && p2.value) ? 'flex' : 'none';
  if (!match && p2.value) p2.classList.add('ft-input--error');
  else p2.classList.remove('ft-input--error');
  return match;
}

/* ── Deshabilitar botón en submit ────────────────────────── */
function setupSubmitLock(formId, btnId, loadingText) {
  const form = document.getElementById(formId);
  const btn  = document.getElementById(btnId);
  if (!form || !btn) return;
  form.addEventListener('submit', (e) => {
    // Validación básica antes de enviar
    const inputs = form.querySelectorAll('input[required], select[required]');
    let valid = true;
    inputs.forEach(el => {
      if (!el.value.trim()) {
        el.classList.add('ft-input--error');
        valid = false;
      } else {
        el.classList.remove('ft-input--error');
      }
    });
    if (!valid) { e.preventDefault(); return; }

    btn.disabled     = true;
    btn.textContent  = loadingText;
  });
}

/* ── Init ─────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {

  // Si hay error de signup, abrir tab signup automáticamente
  const signupPanel = document.getElementById('panel-signup');
  if (signupPanel && signupPanel.querySelector('.auth-alert')) {
    switchTab('signup');
  }

  // Si hay parámetro ?tab=signup en URL
  if (window.location.search.includes('tab=signup')) {
    switchTab('signup');
  }

  // Toggles de contraseña
  setupToggle('togglePwd',   'password');
  setupToggle('toggleSuPwd', 'su-password');

  // Validación match en tiempo real
  const confirm = document.getElementById('su-confirm');
  if (confirm) confirm.addEventListener('input', checkMatch);

  // Lock on submit
  setupSubmitLock('loginForm',  'submitLoginBtn',  'Verificando...');
  setupSubmitLock('signupForm', 'submitSignupBtn', 'Creando cuenta...');

});
