/**
 * public/js/main.js
 * JavaScript del cliente - comportamientos de UI.
 */

'use strict';

// Auto-ocultar alertas de flash tras 4 segundos
document.addEventListener('DOMContentLoaded', () => {
  const alerts = document.querySelectorAll('.alert');
  alerts.forEach(alert => {
    setTimeout(() => {
      alert.style.transition = 'opacity 500ms ease';
      alert.style.opacity = '0';
      setTimeout(() => alert.remove(), 500);
    }, 4000);
  });
});
