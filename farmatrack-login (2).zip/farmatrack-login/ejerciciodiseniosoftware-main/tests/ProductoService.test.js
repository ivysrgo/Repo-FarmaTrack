/**
 * tests/ProductoService.test.js
 * Tests unitarios del servicio - valida la lógica de negocio.
 * Se usa un repositorio mock (Dependency Inversion en acción).
 */

'use strict';

const ProductoService = require('../src/services/ProductoService');
const AppError = require('../src/utils/AppError');

// ── Mock del repositorio ──────────────────────────────────────────────────────
const mockRepo = {
  findAll: jest.fn(),
  findById: jest.fn(),
  findByCategoria: jest.fn(),
  getCategorias: jest.fn(),
  create: jest.fn(),
  update: jest.fn(),
  delete: jest.fn(),
  count: jest.fn(),
};

const service = new ProductoService(mockRepo);

// ── Datos de prueba ───────────────────────────────────────────────────────────
const productoMock = {
  id: 'abc-123',
  nombre: 'Laptop',
  descripcion: 'Una laptop',
  precio: 1500,
  cantidad: 5,
  categoria: 'Electrónica',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
};

// ── Tests ──────────────────────────────────────────────────────────────────────
describe('ProductoService', () => {

  beforeEach(() => jest.clearAllMocks());

  // ── obtenerTodos ─────────────────────────────────────────────────────────
  describe('obtenerTodos()', () => {
    it('retorna lista y estadísticas', async () => {
      mockRepo.findAll.mockResolvedValue([productoMock]);
      mockRepo.count.mockResolvedValue(1);
      mockRepo.getCategorias.mockResolvedValue(['Electrónica']);

      const result = await service.obtenerTodos();

      expect(result.productos).toHaveLength(1);
      expect(result.stats.total).toBe(1);
      expect(result.stats.categorias).toBe(1);
    });
  });

  // ── obtenerPorId ─────────────────────────────────────────────────────────
  describe('obtenerPorId()', () => {
    it('retorna el producto si existe', async () => {
      mockRepo.findById.mockResolvedValue(productoMock);
      const result = await service.obtenerPorId('abc-123');
      expect(result).toEqual(productoMock);
    });

    it('lanza AppError 404 si no existe', async () => {
      mockRepo.findById.mockResolvedValue(null);
      await expect(service.obtenerPorId('no-existe')).rejects.toThrow(AppError);
    });

    it('lanza AppError 400 si no se pasa ID', async () => {
      await expect(service.obtenerPorId(null)).rejects.toThrow(AppError);
    });
  });

  // ── crear ─────────────────────────────────────────────────────────────────
  describe('crear()', () => {
    it('crea un producto con datos válidos', async () => {
      mockRepo.create.mockResolvedValue(productoMock);
      const result = await service.crear({
        nombre: 'Laptop', precio: 1500, cantidad: 5, categoria: 'Electrónica',
      });
      expect(mockRepo.create).toHaveBeenCalledTimes(1);
      expect(result).toEqual(productoMock);
    });

    it('lanza error si nombre está vacío', async () => {
      await expect(service.crear({ nombre: '', precio: 100, cantidad: 1 }))
        .rejects.toThrow(AppError);
    });

    it('lanza error si precio es negativo', async () => {
      await expect(service.crear({ nombre: 'X', precio: -10, cantidad: 1 }))
        .rejects.toThrow(AppError);
    });

    it('lanza error si cantidad es negativa', async () => {
      await expect(service.crear({ nombre: 'X', precio: 10, cantidad: -1 }))
        .rejects.toThrow(AppError);
    });
  });

  // ── actualizar ────────────────────────────────────────────────────────────
  describe('actualizar()', () => {
    it('actualiza un producto existente', async () => {
      mockRepo.findById.mockResolvedValue(productoMock);
      mockRepo.update.mockResolvedValue({ ...productoMock, nombre: 'Laptop Actualizada' });

      const result = await service.actualizar('abc-123', { nombre: 'Laptop Actualizada' });
      expect(result.nombre).toBe('Laptop Actualizada');
    });

    it('lanza error 404 si el producto no existe', async () => {
      mockRepo.findById.mockResolvedValue(null);
      await expect(service.actualizar('no-existe', { nombre: 'X' })).rejects.toThrow(AppError);
    });
  });

  // ── eliminar ──────────────────────────────────────────────────────────────
  describe('eliminar()', () => {
    it('elimina correctamente un producto existente', async () => {
      mockRepo.findById.mockResolvedValue(productoMock);
      mockRepo.delete.mockResolvedValue(true);

      await expect(service.eliminar('abc-123')).resolves.toBeUndefined();
    });

    it('lanza error 404 si el producto no existe', async () => {
      mockRepo.findById.mockResolvedValue(null);
      await expect(service.eliminar('no-existe')).rejects.toThrow(AppError);
    });
  });
});
