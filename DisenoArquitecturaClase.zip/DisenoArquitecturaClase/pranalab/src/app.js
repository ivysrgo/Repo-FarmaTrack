import express from 'express';
import { join } from 'path';
import expressLayouts from 'express-ejs-layouts';
import appRouter from './routes/router.js';

const app  = express();
const port = 3000;

// ── Motor de plantillas ──────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', 'views');
app.use(expressLayouts);
app.set('layout', 'layouts/main');

// ── Middlewares ───────────────────────────────────────────
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(join('./public')));

// ── Rutas ─────────────────────────────────────────────────
app.use('/', appRouter);

// ── Arranque ──────────────────────────────────────────────
app.listen(port, () => {
  console.log(`\n🚀 FarmaTrack corriendo en: http://localhost:${port}`);
  console.log(`📋 No conformidad: http://localhost:${port}/noconformidad/nueva\n`);
});
